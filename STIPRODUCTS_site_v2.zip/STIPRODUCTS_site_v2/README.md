# STIPRODUCTS Website v2.0

Site de prezentare corporativă pentru STIPRODUCTS SRL: Digital, Products, Production, Trade.

## Structura

```
index.html
styles.css
script.js
assets/logo/                 logo-uri web (SVG + PNG)
assets/logo/source/          original CorelDRAW (.cdr) și PDF
```

Nu sunt necesare instalări. Deschide `index.html` în browser sau rulează un server local.

## Testare locală

1. Deschide folderul proiectului.
2. Dublu-click pe `index.html`, sau din terminal:

```bash
python3 -m http.server 8080
```

3. Accesează `http://localhost:8080`.
4. Verifică RO / EN / DE din header — limba se schimbă fără reîncărcarea paginii.

## Logo vectorial — cum se modifică

Fișierul **CDR (CorelDRAW) nu poate fi folosit direct pe web**. Browserul are nevoie de **SVG** (vector) și, opțional, **PNG** (raster).

Flux recomandat:

1. Deschide `assets/logo/source/stiproducts.cdr` în CorelDRAW, Adobe Illustrator sau Inkscape.
2. Exportă:
   - `stiproducts-gold.svg` — versiune aurie pentru fundal negru
   - `stiproducts-light.svg` — versiune deschisă
   - `stiproducts-dark.svg` — versiune închisă pentru fundal deschis
3. Păstrează **aceleași nume de fișiere** și înlocuiește-le în `assets/logo/`.
4. Nu schimba forma, proporțiile sau ligatura STI. Schimbi doar fișierul, nu HTML-ul, dacă numele rămâne identic.

Unde este folosit logo-ul:

- Header / footer: `assets/logo/stiproducts-gold.svg`
- Hero (marcaj): `assets/logo/sti-mark-gold.svg`
- About: `assets/logo/stiproducts-dark.svg`

Versiunile SVG din acest pachet sunt generate din preview-ul oficial, fără a altera identitatea. Pentru reproducere maximă, re-exportă tu din CDR.

Culoarea din fișierul sursă apare albastră în PDF (CMYK). Pe site este folosită paleta corporativă negru / alb / auriu, **fără modificarea formei**.

## Formular de contact

Formularul **nu** se bazează pe `mailto:`.

În `script.js`:

```js
const CONTACT_CONFIG = {
  endpoint: "",   // ex: https://formspree.io/f/xxxx
  method: "POST"
};
```

Până setezi `endpoint`, mesajele se salvează local în browser (`localStorage`, cheia `stiproducts_inquiries`).

Adresa `contact@stipproducts.ro` este **provizorie**.

## Ce nu este publicat încă

Nu completa automat înainte de confirmare:

- sediu, CUI, nr. ONRC, telefon
- prețuri, stocuri, capacitate de producție
- certificate sau autorizații
- disponibilitate comercială a produselor fizice

STI Silver: medalia Lakshmi & Ganesha este obiect de colecție, nu monedă cu putere circulatorie.

## Publicare

1. Confirmă emailul și datele legale.
2. Setează `CONTACT_CONFIG.endpoint`.
3. Încarcă tot folderul pe hosting (Netlify, Vercel, cPanel etc.).
4. Adaugă domeniul și HTTPS.
5. Actualizează politica de confidențialitate după serviciul real de email.

## SEO

- Title și description se actualizează la schimbarea limbii și a secțiunii.
- JSON-LD Organization este inclus, fără date neconfirmate.

## v1.0 păstrat

Designul premium negru / alb / auriu, selectorul de limbă fără reload, meniul mobil, principiile și animațiile discrete au fost păstrate și extinse la cinci divizii.
